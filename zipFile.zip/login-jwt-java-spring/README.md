# 🔐 Secure Login JWT (Java + Spring Boot)

Sistema de autenticação com cadastro, login, token JWT, senha criptografada e banco de dados H2.

## ✨ Funcionalidades

- Cadastro de usuário
- Login com validação de credenciais
- Geração de token JWT
- Área protegida por token
- Senhas criptografadas com BCrypt
- Banco de dados H2 persistente
- Interface moderna com HTML, CSS e JavaScript

## 🛠️ Tecnologias

- Java 11
- Spring Boot
- Spring Security
- Spring Data JPA
- H2 Database
- HTML5
- CSS3
- JavaScript

## 📦 Como rodar

```bash
mvn spring-boot:run
```

Depois acesse a porta `8080`.

## 🧪 Endpoints principais

| Método | Rota | Descrição |
|---|---|---|
| POST | `/api/auth/register` | Cadastrar usuário |
| POST | `/api/auth/login` | Login e geração de JWT |
| GET | `/api/auth/me` | Buscar usuário autenticado |

## 🎯 Objetivo

Projeto criado para portfólio, com foco em autenticação, segurança básica, API REST e persistência de dados.
