\
package com.joaovitor.auth;

import org.springframework.stereotype.Service;
import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import java.nio.charset.StandardCharsets;
import java.time.Instant;
import java.util.Base64;

@Service
public class JwtService {
    private static final String SECRET = "chave-super-secreta-do-projeto-joao-vitor";
    private static final long EXPIRATION_SECONDS = 60 * 60 * 2;

    public String gerarToken(String email) {
        long exp = Instant.now().getEpochSecond() + EXPIRATION_SECONDS;
        String headerJson = "{\"alg\":\"HS256\",\"typ\":\"JWT\"}";
        String payloadJson = "{\"sub\":\"" + email + "\",\"exp\":" + exp + "}";
        String header = base64Url(headerJson);
        String payload = base64Url(payloadJson);
        String signature = hmacSha256(header + "." + payload);
        return header + "." + payload + "." + signature;
    }

    public String validarTokenEObterEmail(String token) {
        try {
            String[] parts = token.split("\\.");
            if (parts.length != 3) return null;
            String expected = hmacSha256(parts[0] + "." + parts[1]);
            if (!expected.equals(parts[2])) return null;

            String payloadJson = new String(Base64.getUrlDecoder().decode(parts[1]), StandardCharsets.UTF_8);
            String email = extrairEntre(payloadJson, "\"sub\":\"", "\"");
            String expText = extrairDepois(payloadJson, "\"exp\":").replace("}", "").trim();

            long exp = Long.parseLong(expText);
            if (Instant.now().getEpochSecond() > exp) return null;

            return email;
        } catch (Exception e) {
            return null;
        }
    }

    private String base64Url(String value) {
        return Base64.getUrlEncoder().withoutPadding().encodeToString(value.getBytes(StandardCharsets.UTF_8));
    }

    private String hmacSha256(String data) {
        try {
            Mac mac = Mac.getInstance("HmacSHA256");
            SecretKeySpec key = new SecretKeySpec(SECRET.getBytes(StandardCharsets.UTF_8), "HmacSHA256");
            mac.init(key);
            return Base64.getUrlEncoder().withoutPadding().encodeToString(mac.doFinal(data.getBytes(StandardCharsets.UTF_8)));
        } catch (Exception e) {
            throw new RuntimeException("Erro ao gerar JWT");
        }
    }

    private String extrairEntre(String text, String start, String end) {
        int startIndex = text.indexOf(start);
        if (startIndex == -1) return null;
        startIndex += start.length();
        int endIndex = text.indexOf(end, startIndex);
        if (endIndex == -1) return null;
        return text.substring(startIndex, endIndex);
    }

    private String extrairDepois(String text, String start) {
        int startIndex = text.indexOf(start);
        if (startIndex == -1) return "";
        return text.substring(startIndex + start.length());
    }
}
